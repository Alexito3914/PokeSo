#!/bin/bash

# Abrir nano en una nueva ventana de terminal
gnome-terminal -- nano

