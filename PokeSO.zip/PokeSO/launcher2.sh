#!/bin/bash

# Ruta al archivo Python que deseas ejecutar
RUTA_PYTHON="./tresenraya.py"

# Ejecutar el archivo Python en una nueva ventana de terminal
gnome-terminal -- python3 "$RUTA_PYTHON"
sleep 1
