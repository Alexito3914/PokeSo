#!/bin/bash

# Abrir Nautilus en una nueva ventana de terminal
gnome-terminal -- nautilus

