#!/bin/bash

PADRE_PID=$PPID
x-terminal-emulator -e "python3 -u pokeshell.py $PADRE_PID"

